create function          get_relations(v1_cusno      varchar2,
                                         v2_cusno      varchar2,
                                         relation_code varchar2)
  return varchar2 is
  relation_name varchar2(50);
  v1_sex        varchar2(2);
  v2_sex        varchar2(2);
  v1_birthday   date;
  v2_birthday   date;

begin

  --将第一个客户号的性别和出生日期查询出来并赋值给对应变量
  select m1.sex, m1.birthday
    into v1_sex, v1_birthday
    from cf_customermaininfo m1
   where m1.customerno = v1_cusno;

  --将第二个客户号的性别和出生日期查询出来并赋值给对应变量
  select m2.sex, m2.birthday
    into v2_sex, v2_birthday
    from cf_customermaininfo m2
   where m2.customerno = v2_cusno;

  --01  父子  02  父女  03  母子  04  母女  05  祖孙  07  夫妻  08  兄弟  09  兄妹  10  姐弟  11  姐妹
  --12  叔侄  13  姑    14  外甥  15  媳    16  婿    17  姐夫
  --18  朋友  19  同事  20  师生  21  雇佣  22  其他  23  法定  24  银行  25  外甥女

  case
  --01 父子关系
    when relation_code = '01' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的父亲
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '父亲';
      else
        relation_name := '儿子';
      end if;

  --02 父女关系
    when relation_code = '02' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的父亲
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '父亲';
      else
        relation_name := '女儿';
      end if;

  --03 母子关系
    when relation_code = '03' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的母亲
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '母亲';
      else
        relation_name := '儿子';
      end if;

  --04 母女关系
    when relation_code = '04' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的母亲
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '母亲';
      else
        relation_name := '女儿';
      end if;

  --05 祖孙关系
    when relation_code = '05' then
      --如果客户1出生日期比客户2出生日期早 男的为祖父 女的为祖母
      if months_between(v1_birthday, v2_birthday) < 0 then
        if v1_sex = '0' then
          relation_name := '祖父';
        elsif v1_sex = '1' then
          relation_name := '祖母';
        else
          relation_name := '未知';
        end if;
      else
        if v1_sex = '0' then
          relation_name := '孙子';
        elsif v1_sex = '1' then
          relation_name := '孙女';
        else
          relation_name := '未知';
        end if;
      end if;

  --07 夫妻关系
    when relation_code = '07' then
      if v1_sex = '0' then
        relation_name := '丈夫';
      elsif v1_sex = '1' then
        relation_name := '妻子';
      else
        relation_name := '未知';
      end if;

  --08  兄弟
    when relation_code = '08' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的哥哥
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '哥哥';
      else
        relation_name := '弟弟';
      end if;

  --09  兄妹
    when relation_code = '09' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的哥哥
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '哥哥';
      else
        relation_name := '妹妹';
      end if;

  --10  姐弟
    when relation_code = '10' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的哥哥
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '姐姐';
      else
        relation_name := '弟弟';
      end if;

  --11  姐妹
    when relation_code = '11' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的姐姐
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '姐姐';
      else
        relation_name := '妹妹';
      end if;

  --12  叔侄
    when relation_code = '12' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的叔叔
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '叔叔';
      else
        if v1_sex = '0' then
          relation_name := '侄子';
        elsif v1_sex = '1' then
          relation_name := '侄女';
        else
          relation_name := '未知';
        end if;
      end if;

  --13  姑侄
    when relation_code = '13' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的姑姑
      if months_between(v1_birthday, v2_birthday) < 0 then
        relation_name := '姑姑';
      else
        if v1_sex = '0' then
          relation_name := '侄子';
        elsif v1_sex = '1' then
          relation_name := '侄女';
        else
          relation_name := '未知';
        end if;
      end if;

  --14  外甥
    when relation_code = '14' then
      --如果客户1出生日期比客户2出生日期早,则客户1是客户2 的
      if months_between(v1_birthday, v2_birthday) < 0 then
        if v1_sex = '0' then
          relation_name := '舅舅';
        elsif v1_sex = '1' then
          relation_name := '舅妈';
        else
          relation_name := '未知';
        end if;
      else
        if v1_sex = '0' then
          relation_name := '外甥';
        elsif v1_sex = '1' then
          relation_name := '外甥女';
        else
          relation_name := '未知';
        end if;
      end if;

  --15  媳
    when relation_code = '15' then
      --如果客户1出生日期比客户2出生日期晚,则客户1是客户2 儿媳
      if months_between(v1_birthday, v2_birthday) > 0 then
        relation_name := '儿媳';
      else
        if v1_sex = '0' then
          relation_name := '公公';
        elsif v1_sex = '1' then
          relation_name := '婆婆';
        else
          relation_name := '未知';
        end if;
      end if;

  --16  婿
    when relation_code = '16' then
      --如果客户1出生日期比客户2出生日期晚,则客户1是客户2 女婿
      if months_between(v1_birthday, v2_birthday) > 0 then
        relation_name := '女婿';
      else
        if v1_sex = '0' then
          relation_name := '岳父';
        elsif v1_sex = '1' then
          relation_name := '岳母';
        else
          relation_name := '未知';
        end if;
      end if;

  --其他关系不具体判断，只展示两人之间的关系
    else
      select c.codename
        into relation_name
        from cf_codedef c
       where 1 = 1
         and c.code = relation_code
         and c.codetype = 'relation';

  end case;

  return relation_name;

end;
/

