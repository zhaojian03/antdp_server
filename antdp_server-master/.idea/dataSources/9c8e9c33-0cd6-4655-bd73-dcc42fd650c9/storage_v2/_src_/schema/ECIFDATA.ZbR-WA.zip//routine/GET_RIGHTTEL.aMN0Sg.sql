create function get_righttel(v1_telno      varchar2,
                                        v2_telno      varchar2,
                                        v3_telno      varchar2,
                                        v4_telno      varchar2,
                                        v5_telno      varchar2,
                                        v6_telno      varchar2,
                                        v7_telno      varchar2,
                                        v8_telno      varchar2,
                                        v9_telno      varchar2)
  return varchar2 is
  right_tel varchar2(50);


begin

  if regexp_like(trim(v1_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v1_telno;

  elsif regexp_like(trim(v2_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v2_telno;

  elsif regexp_like(trim(v3_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v3_telno;

  elsif regexp_like(trim(v4_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v4_telno;

  elsif regexp_like(trim(v5_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v5_telno;

  elsif regexp_like(trim(v6_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v6_telno;

  elsif regexp_like(trim(v7_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v7_telno;

  elsif regexp_like(trim(v8_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v8_telno;

  elsif regexp_like(trim(v9_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
     right_tel := v9_telno;

  end if;
 return right_tel;
end;
/

