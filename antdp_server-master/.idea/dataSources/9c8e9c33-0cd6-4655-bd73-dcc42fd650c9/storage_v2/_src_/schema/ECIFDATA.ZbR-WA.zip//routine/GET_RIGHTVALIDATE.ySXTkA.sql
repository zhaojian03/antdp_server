create function get_rightvalidate(oldvalidate   varchar2)

  return varchar2 is
  rightvalidate varchar2(10);


begin


  if instr(oldvalidate,'/')>0 then
     rightvalidate := to_char(to_date(oldvalidate,'yyyy/mm/dd'),'yyyy/mm/dd');

  elsif instr(oldvalidate,'.')>0 then
     rightvalidate := to_char(to_date(oldvalidate,'yyyy/mm/dd'),'yyyy/mm/dd');

  elsif instr(oldvalidate,'-')>0 then
     rightvalidate := to_char(to_date(oldvalidate,'yyyy/mm/dd'),'yyyy/mm/dd');

  elsif oldvalidate is null then
     rightvalidate := '';
  elsif (trim(oldvalidate))='' then
     rightvalidate := '';

  elsif instr(oldvalidate,'null')>0 then
     rightvalidate := '';
  elsif instr(oldvalidate,'年')>0 then
     rightvalidate := to_char(to_date(replace(replace(replace(oldvalidate,'年','/'),'月','/'),'日',''),'yyyy/mm/dd'),'yyyy/mm/dd');

  else
    rightvalidate := to_char(to_date(oldvalidate,'yyyymmdd'),'yyyy/mm/dd');

  end if;
  return rightvalidate;
exception
  when others then
  rightvalidate := '';

 return rightvalidate;
end;
/

