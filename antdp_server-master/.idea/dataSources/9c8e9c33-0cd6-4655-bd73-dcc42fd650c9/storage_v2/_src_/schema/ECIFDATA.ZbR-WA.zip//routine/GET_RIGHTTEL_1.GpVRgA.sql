create FUNCTION GET_RIGHTTEL_1 (ca_telno      varchar2,
                                        ha_telno      varchar2,
                                        da_telno      varchar2,                                       
                                        teltype      varchar2)

  return varchar2 is
  right_tel varchar2(50);
declare
  v1_telno      varchar2(20);
  v2_telno      varchar2(20);
  v3_telno      varchar2(20);
  v4_telno      varchar2(20);
  v5_telno      varchar2(20);
  v6_telno      varchar2(20);
  v7_telno      varchar2(20);
  v8_telno      varchar2(20);
  v9_telno      varchar2(20);


begin
  v1_telno := regexp_substr(ca_telno,'[^;]+',1,2);
  v2_telno := regexp_substr(ca_telno,'[^;]+',1,1);
  v3_telno := regexp_substr(ca_telno,'[^;]+',1,3);

  v4_telno := regexp_substr(ha_telno,'[^;]+',1,1);
  v5_telno := regexp_substr(ha_telno,'[^;]+',1,2);
  v6_telno := regexp_substr(ha_telno,'[^;]+',1,3);

  v7_telno := regexp_substr(da_telno,'[^;]+',1,1);
  v8_telno := regexp_substr(da_telno,'[^;]+',1,2);
  v9_telno := regexp_substr(da_telno,'[^;]+',1,3);
  -- if teltype = '1' then
    if regexp_like(trim(v1_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v1_telno;

    elsif regexp_like(trim(v2_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v2_telno;

    elsif regexp_like(trim(v3_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v3_telno;

    elsif regexp_like(trim(v4_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v4_telno;

    elsif regexp_like(trim(v5_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v5_telno;

    elsif regexp_like(trim(v6_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v6_telno;

    elsif regexp_like(trim(v7_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v7_telno;

    elsif regexp_like(trim(v8_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v8_telno;

    elsif regexp_like(trim(v9_telno),'^1[3,4,5,6.7,8,9][[:digit:]]{9}$') then
       right_tel := v9_telno;
    
/*  
elsif teltype = '0' then
     if regexp_like(trim(v1_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v1_telno;

    elsif regexp_like(trim(v2_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v2_telno;

    elsif regexp_like(trim(v3_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v3_telno;

    elsif regexp_like(trim(v4_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v4_telno;

    elsif regexp_like(trim(v5_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v5_telno;

    elsif regexp_like(trim(v6_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v6_telno;

    elsif regexp_like(trim(v7_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v7_telno;

    elsif regexp_like(trim(v8_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v8_telno;

    elsif regexp_like(trim(v9_telno),'/0\d{2,3}-\d{7,8}/') then
       right_tel := v9_telno;

    elsif regexp_like(trim(v1_telno),'\d{7,8}/') then
       right_tel := v1_telno;

    elsif regexp_like(trim(v2_telno),'\d{7,8}/') then
       right_tel := v2_telno;

    elsif regexp_like(trim(v3_telno),'\d{7,8}/') then
       right_tel := v3_telno;

    elsif regexp_like(trim(v4_telno),'\d{7,8}/') then
       right_tel := v4_telno;

    elsif regexp_like(trim(v5_telno),'\d{7,8}/') then
       right_tel := v5_telno;

    elsif regexp_like(trim(v6_telno),'\d{7,8}/') then
       right_tel := v6_telno;

    elsif regexp_like(trim(v7_telno),'\d{7,8}/') then
       right_tel := v7_telno;

    elsif regexp_like(trim(v8_telno),'\d{7,8}/') then
       right_tel := v8_telno;

    elsif regexp_like(trim(v9_telno),'\d{7,8}/') then
       right_tel := v9_telno;
    end if;*/
  end if;
  /

